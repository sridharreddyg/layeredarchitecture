package com.cg.hm.service;

import java.util.Map;

import com.cg.hm.Exception.HotelException;
import com.cg.hm.dto.Hotel;

public interface HotelService {
	int insertIntoMap(Hotel hotel)throws HotelException;

	void validateName(String guestname) throws HotelException;

	void validateAddress(String address)throws HotelException;

	void validatePhone(String phone)throws HotelException;

	void validateRoom(String roomtype)throws HotelException;

	void validateBed(String bedtype)throws HotelException;

	void validateDays(String days)throws HotelException;

	void validateOrderId(int roomnumber)throws HotelException;

	Hotel guestDetails(int roomnumber)throws HotelException;
	

}
