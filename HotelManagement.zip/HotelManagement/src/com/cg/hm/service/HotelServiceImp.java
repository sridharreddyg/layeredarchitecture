package com.cg.hm.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.hm.Exception.HotelException;
import com.cg.hm.dao.HotelInt;
import com.cg.hm.dao.HotelIntImp;
import com.cg.hm.dto.Hotel;
public class HotelServiceImp implements HotelService{
	HotelInt hoteldao=new HotelIntImp();
	@Override
	public int insertIntoMap(Hotel hotel) throws HotelException {
		return hoteldao.insertIntoMap(hotel);	
	}

	@Override
	public void validateName(String guestname) throws HotelException {
		String nameRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(nameRegEx, guestname) == false) {
			throw new HotelException("name should contain only alphabets");
		}	
	}

	@Override
	public void validateAddress(String address) throws HotelException{
		String addressRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(addressRegEx, address) == false) {
			throw new HotelException("address should contain only alphabets");
		}
		
	}

	@Override
	public void validatePhone(String phone)throws HotelException {
		String phoneRegEx = "[7|8|9]{1}[0-9]{9}";
		if (Pattern.matches(phoneRegEx, phone) == false) {
			throw new HotelException("mobile number should contain exactly 10 digits");
		}	
	}

	@Override
	public void validateRoom(String roomtype) throws HotelException{
		String nameRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(nameRegEx, roomtype) == false) {
			throw new HotelException("Enter only Ac/non-Ac");
		}
		
	}

	@Override
	public void validateBed(String bedtype)throws HotelException {
		String nameRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(nameRegEx, bedtype) == false) {
			throw new HotelException("Enter single or double Type ");
		}
		
	}

	@Override
	public void validateDays(String days) throws HotelException {
		String nameRegEx = "[1-30]";
		if (Pattern.matches(nameRegEx, days) == false) {
			throw new HotelException("enter days only");
		}
		
	}

	@Override
	public void validateOrderId(int roomnumber) throws HotelException {
		String idRegEx = "[0-9]+";
		if (Pattern.matches(idRegEx, String.valueOf(roomnumber)) == false) {
			throw new HotelException("roomnumber  should contain only digits");
		}
		
	}

	@Override
	public Hotel guestDetails(int roomnumber) throws HotelException {
		return hoteldao.guestDetails(roomnumber);
		// TODO Auto-generated method stub
		
	}

	

}
