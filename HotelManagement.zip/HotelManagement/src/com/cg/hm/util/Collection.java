package com.cg.hm.util;

import java.util.HashMap;
import java.util.Map;
import com.cg.hm.dto.Hotel;
public class Collection {
public static Map<Integer,Hotel> hotelmap=new HashMap<>();
static{
	hotelmap.put(11, new Hotel(11,"sahith","hyderabad","1234567897","Ac","single","2","1/05/2019"));
	hotelmap.put(22, new Hotel(22,"vijay","chnnai","1239867897","non-ac","double","1","30/05/2019"));
}
public static int insertIntoMap(Hotel hotel) {
	hotelmap.put(hotel.getRoomno(),hotel);
	return hotel.getRoomno();	
}
public static Hotel guestDetails(int roomnumber) {
	return hotelmap.get(roomnumber);
}
}
