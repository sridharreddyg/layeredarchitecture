package com.cg.hm.dao;
import java.util.Set;
import com.cg.hm.Exception.HotelException;
import com.cg.hm.dto.Hotel;
import com.cg.hm.util.Collection;
public class HotelIntImp implements HotelInt{
	Collection c=new Collection();
	@Override
	public int insertIntoMap(Hotel hotel) throws HotelException {
		return Collection.insertIntoMap(hotel);
	}
	@Override
	public Hotel guestDetails(int roomnumber) throws HotelException {
		Hotel hotel=null;
		boolean flag = false;

		Set<Integer> set = Collection.hotelmap.keySet();
		for (int id : set) {
			if (id == roomnumber) {
				
				Hotel h = Collection.hotelmap.get(id);	
				hotel = Collection.hotelmap.get(id);
				break;
			}
		}
		if(hotel==null)
			throw new HotelException("no details present with the given number");
	return hotel;
			}

		}		
	

