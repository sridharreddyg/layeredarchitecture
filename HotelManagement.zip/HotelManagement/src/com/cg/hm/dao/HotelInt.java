package com.cg.hm.dao;

import java.util.Map;

import com.cg.hm.Exception.HotelException;
import com.cg.hm.dto.Hotel;

public interface HotelInt {
	int insertIntoMap(Hotel hotel)throws HotelException;

	 Hotel guestDetails(int roomnumber) throws HotelException;
}
