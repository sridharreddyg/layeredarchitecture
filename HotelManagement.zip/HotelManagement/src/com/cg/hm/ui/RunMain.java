package com.cg.hm.ui;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import org.omg.Messaging.SYNC_WITH_TRANSPORT;

import java.util.Calendar;
import com.cg.hm.Exception.HotelException;
import com.cg.hm.dto.Hotel;
import com.cg.hm.service.HotelService;
import com.cg.hm.service.HotelServiceImp;
public class RunMain {
	public static void main(String[] args) throws HotelException {
		HotelService hsi=new  HotelServiceImp();
		Scanner sc=null;
		String continueChoice ;
		System.out.println("welcome to Capgemini Hotel");
		do {
		System.out.println("1.Book a Room\n2:Room Details\n3:exit");
		int choice;
		boolean choiceFlag = false;
		do {
			sc=new Scanner(System.in);
			System.out.println("enter your choice");
			try {
				
				 choice=sc.nextInt();
				choiceFlag = true;
				String guestname;
				switch (choice) {
				case 1:
					boolean nameFlag = false;
					do {
						sc = new Scanner(System.in);
						System.out.println("Enter name of the guest");
						guestname = sc.nextLine();
						try {
							hsi.validateName(guestname);
							nameFlag = true;
							break;

						} catch (HotelException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!nameFlag);
					String guestaddress;
					boolean addressFlag = false;
					do {
						sc = new Scanner(System.in);
						System.out.println("Enter address of the customer");
						guestaddress = sc.nextLine();
						try {
							hsi.validateAddress(guestaddress);
							addressFlag = true;
							break;

						} catch (HotelException e) {
							addressFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!addressFlag);
					String phone;
					boolean phoneFlag = false;
					do {
						sc = new Scanner(System.in);
						System.out.println("Enter phone number of the customer");
						phone = sc.nextLine();
						try {
							hsi.validatePhone(phone);
							phoneFlag = true;
							break;

						} catch (HotelException e) {
							phoneFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!phoneFlag);
					String roomtype;
					boolean roomFlag = false;
					do {
						sc = new Scanner(System.in);
						System.out.println("Enter roomtype");
						roomtype= sc.nextLine();
						try {
							hsi.validateRoom(roomtype);
							roomFlag = true;
							break;

						} catch (HotelException e) {
							roomFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!roomFlag);
					String bedtype;
					boolean bedFlag=false;
					do {
						sc=new Scanner(System.in);
						System.out.println("enter the bed type");
						bedtype=sc.nextLine();
						try {
							hsi.validateBed(bedtype);
							bedFlag=true;
							break;	
						}catch(HotelException e) {
							bedFlag=false;
							System.err.println(e.getMessage());		
						}	
					}while(!bedFlag);
					String days;
					boolean dayflag=false;
					do {
						sc=new Scanner(System.in);
						System.out.println("enter how many days you want to stay");
						days=sc.next();
						try {
							hsi.validateDays(days);
							dayflag=true;
							break;
						}catch(HotelException e) {
							dayflag=false;
							System.err.println(e.getMessage());
						}
						
					}while(dayflag);
					do {
					DateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
					Calendar cal=Calendar.getInstance();
					cal.add(Calendar.DAY_OF_MONTH,Integer.parseInt(days));
					String checkout=sdf.format(cal.getTime());
					int roomno=(int) (Math.random()*100);
						Hotel hotel=new Hotel(roomno, guestname, guestaddress, phone, roomtype, bedtype,days,checkout);
						try {
							int roomnumber = hsi.insertIntoMap(hotel);
							System.out.println("you successfully booked your room " );
							System.out.println("your room number is: "+ roomnumber);
						} catch (HotelException e) {
							System.err.println(e.getMessage());
						}
					}while(!true);
					break;
				case 2:
					int roomnumber = 0;
					boolean roomnumberFlag = false;
					do {
						sc = new Scanner(System.in);
						System.out.println("Enter the room number");
						try {
							roomnumber = sc.nextInt();
							hsi.validateOrderId(roomnumber);
							System.out.println(hsi.guestDetails(roomnumber));
							roomnumberFlag = true;
							break;

						} catch (InputMismatchException e) {
							roomnumberFlag = false;
							System.err.println(e.getMessage());
						} catch (HotelException e) {
							System.err.println(e.getMessage());
						}
					} while (!roomnumberFlag);
					break;
				case 3:
					System.exit(0);
					break;

				default:
					System.out.println("enter only 1/2/3");;
				}
			}catch(InputMismatchException e)
			{
				choiceFlag = false;
				System.err.println("enter only digits");	
			}
		}while(!choiceFlag);
		
		System.out.println("do u want to continue again(yes/no)");
		continueChoice = sc.next();
		}while(continueChoice.equalsIgnoreCase("yes"));
		
	}

}
