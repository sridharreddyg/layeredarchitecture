package com.cg.hm.dto;

import java.util.Date;

public class Hotel {
private int roomno;
@Override
public String toString() {
	return "Hotel Capgemini [roomno=" + roomno + ", guestname=" + guestname + ", guestaddress=" + guestaddress + ", mobileno="
			+ mobileno + ", roomtype=" + roomtype + ", bedtype=" + bedtype + ", days=" + days + ", checout=" + checout
			+ "]";
}
public int getRoomno() {
	return roomno;
}
public void setRoomno(int roomno) {
	this.roomno = roomno;
}
public String getGuestname() {
	return guestname;
}
public void setGuestname(String guestname) {
	this.guestname = guestname;
}
public String getGuestaddress() {
	return guestaddress;
}
public void setGuestaddress(String guestaddress) {
	this.guestaddress = guestaddress;
}
public String getMobileno() {
	return mobileno;
}
public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}
private String guestname;
private String guestaddress;
private String mobileno;
private String roomtype;
private String bedtype;
private String days;
public Hotel() {
	super();
}
public String getDays() {
	return days;
}
public void setDays(String days) {
	this.days = days;
}
public String getChecout() {
	return checout;
}
public Hotel(int roomno, String guestname, String guestaddress, String mobileno, String roomtype, String bedtype,
		String days, String checout) {
	super();
	this.roomno = roomno;
	this.guestname = guestname;
	this.guestaddress = guestaddress;
	this.mobileno = mobileno;
	this.roomtype = roomtype;
	this.bedtype = bedtype;
	this.days = days;
	this.checout = checout;
}
public void setChecout(String checout) {
	this.checout = checout;
}
String checout;
public String getBedtype() {
	return bedtype;
}
public void setBedtype(String bedtype) {
	this.bedtype = bedtype;
}
public String getRoomtype() {
	return roomtype;
}
public void setRoomtype(String roomtype) {
	this.roomtype = roomtype;
}


}
