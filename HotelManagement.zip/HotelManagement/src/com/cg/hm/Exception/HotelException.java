package com.cg.hm.Exception;

public class HotelException extends Exception{

	public HotelException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
