package com.cg.hm.dao;
import static org.junit.Assert.*;
import java.util.List;
import java.util.Map;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.cg.hm.Exception.HotelException;
import com.cg.hm.dto.Hotel;
import com.cg.hm.util.Collection;
public class HotelIntImpTest {
HotelIntImp hii=null;
	@Before
	public void setUp() throws Exception {
		hii=new HotelIntImp();
	}

	@After
	public void tearDown() throws Exception {
		hii=null;
	}

	@Test
	public void testInsertIntoMap() {
		Hotel hotel=new Hotel(33,"ram","bangalore","9874461233","ac","single","3","2/05/2019");
		try {
			int roomno = hii.insertIntoMap(hotel);
			assertNotNull(roomno);
		} catch (HotelException e) {

		}
	}
	@Test
	public void testInsertIntoMapNull() {
		Hotel hotel=new Hotel(44,"sri","hyd","9875561233","nonac","double","4","3/05/2019");
		try {
			int roomno = hii.insertIntoMap(hotel);
			assertNull(roomno);
		} catch (HotelException e) {

		}
	}

	@Test
	public void testGuestDetails(){

		try {
			Hotel hotel = hii.guestDetails(11);
			assertNotNull(hotel);
		} catch (HotelException e) {
		}
	}
	}



