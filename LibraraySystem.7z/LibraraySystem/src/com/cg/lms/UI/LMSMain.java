package com.cg.lms.UI;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.concurrent.CopyOnWriteArrayList;

import com.cg.lms.Bean.Book;
import com.cg.lms.Bean.Student;
import com.cg.lms.Exception.LMSException;
import com.cg.lms.Service.LMSService;


public class LMSMain{
	 public static void main(String args []){
		Scanner scan= null;
		LMSService service= new LMSService();
		Student stud= new Student();
		String continuechoice="";
		do{
			System.out.println("--Library Management System--");
			System.out.println("1.Issue Book\n2.Display All Books\n3.Add Book\n4.Delete Book\n5.Exit");
			int choice=0;
			boolean choiceFlag=false;
		do{
			scan= new Scanner(System.in);
			System.out.println("enter your choice");
			try {
					choice=scan.nextInt();
					choiceFlag=true;
					switch(choice){
			case 1:
						String rollNo="";
						boolean rollNoFlag=false;
						do
						{
							System.out.println("enter Your Roll Number");
							scan= new Scanner(System.in);
							try {
								rollNo= scan.next();
								service.validateRollNo(rollNo);
								rollNoFlag=true;
								break;
					

							}
							catch(LMSException e)
							{
								rollNoFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!rollNoFlag);
						String studentName="";
						boolean studentNameFlag=false;
						do
						{
							System.out.println("enter your name");
							scan= new Scanner(System.in);
							try {
								studentName= scan.next();
								service.validateStudentName(studentName);
								stud.setStudentName(studentName);
								studentNameFlag=true;
								break;
					         }
							catch(LMSException e)
							{
								studentNameFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!studentNameFlag);
	
				String availBookName="";
				boolean availBookNameFlag=false;
				do{
					scan= new Scanner(System.in);
					System.out.println("enter book name");
			
						availBookName= scan.next();
					    availBookNameFlag=true;
					    Book bookData;
					    LocalDateTime date= LocalDateTime.now();
					    try{
		bookData=service.searchBookName(availBookName);
		System.out.println("Book Issued to:" + stud.getStudentName()+" on\t"+date );
					    	System.out.println(bookData);
					    	}
					    	catch(LMSException e1){
					    		System.err.println(e1.getMessage());
					    	}
					    }
				while(!availBookNameFlag);
						break;
					
						
			    case 2:
			    	System.out.println("--Books Available in the Library Stock--");
				 CopyOnWriteArrayList<Book> books= null;
				 
						try {
							books=service.getAllBooks();
							
							for(Book obj:books)
							{
								System.out.println(obj);
							}
							break;
						} catch (LMSException e) {
						System.out.println(e.getMessage());
						break;
						}
			    case 3:
			    	System.out.println("Add books into the stock");
			    	String newbookName="";
					boolean newbookNameFlag=false;
			    	do{
							scan= new Scanner(System.in);
							System.out.println("enter book name");
							try{
					    	   newbookName= scan.next();
					    	   service.validateBookName(newbookName);
					    	   
					    	    newbookNameFlag=true;
							}
						 catch(LMSException e1){
							 newbookNameFlag=false;
						 
							  System.err.println(e1.getMessage());
							    	}
							    }
				while(!newbookNameFlag);
		
					String newAuthorName="";
					boolean newAuthorFlag=false;
						    	
						do{
					scan= new Scanner(System.in);
					System.out.println("enter Author name");
					try{
				 newAuthorName= scan.next();
				 newAuthorFlag=true;
				 service.validateAuthorName(newAuthorName);
										}
									 catch(LMSException e1){
										 newAuthorFlag=false;
									 
										  System.err.println(e1.getMessage());
										    	}
									 }
								
					while(!newAuthorFlag);
					
			Book book= new Book(newbookName,newAuthorName);
			try {
				
				Book b = service.addBook(book);
				int id= (int) (Math.random()*1000);
				book.setBookId(id);
				book.setBookName(newbookName);
				book.setAuthorName(newAuthorName);
				System.out.println("Book added with the id: " + b);
			} catch (LMSException e) {
				System.out.println(e.getMessage());
			}
				break;
			    case 4:
			   
			    	System.out.println("Delete books from the stock");
			    	String deletebookName="";
					boolean deleteNameFlag=false;
			    	do{
						scan= new Scanner(System.in);
						System.out.println("enter book name");
						
						 Book deleteBook= new Book(deletebookName);
						 deleteBook.setBookName(deletebookName);
							try{
					    	   deletebookName= scan.next();
					    	 Book delbook=  service.removeBookName(deleteBook);
					    	  
					     //  service.validateBookName(newbookName);
					       
					    	    newbookNameFlag=true;
							}
						 catch(LMSException e1){
							 newbookNameFlag=false;
						 
							  System.err.println(e1.getMessage());
							    	}
							    }
				while(!newbookNameFlag);
		
					
			Book book1= new Book(deletebookName);
			try {
				Book b = service.removeBookName(book1);
				System.out.println(deletebookName+"Book Deleted");
			} catch (LMSException e) {
				System.out.println(e.getMessage());
			}
				break;
			
		 case 5:
			    	System.exit(0);
			    	break;
					}
			}catch(InputMismatchException e) {
				System.err.println("enter digits only");
		
			}
			}
		while(!choiceFlag);
		scan= new Scanner(System.in);
		System.out.println("do u want to continue again(yes/no)");
		continuechoice = scan.next();
	} while (continuechoice.equalsIgnoreCase("yes"));
	//scan.close();
		
		}
	}
	
		
						
