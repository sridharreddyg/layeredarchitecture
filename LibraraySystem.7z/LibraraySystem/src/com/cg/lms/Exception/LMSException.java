package com.cg.lms.Exception;

public class LMSException extends Exception{

	public LMSException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
