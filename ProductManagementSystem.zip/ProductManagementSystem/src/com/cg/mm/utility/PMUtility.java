package com.cg.mm.utility;

import java.util.HashMap;
import java.util.Map;

import com.cg.mm.dto.Product;

public class PMUtility {
	
	static Map<Integer, Product> hm1=new HashMap<Integer,Product>();
	
	static {
		
			hm1.put(101,new Product(101,"Laptop",25000,"Electrical"));
			hm1.put(102,new Product(102,"Mobile",5000,"Electrical"));
			hm1.put(103,new Product(103,"Tab",13000,"Electrical"));
			hm1.put(104,new Product(104,"Charger",900,"Electrical"));
			hm1.put(105,new Product(105,"Battery",5000,"Electrical"));
			hm1.put(106,new Product(106,"LCD",35000,"Electrical"));
			
		
	}

	public static Map<Integer, Product> getHm1() {
		return hm1;
	}

	public static void setHm1(Map<Integer, Product> hm1) {
		PMUtility.hm1 = hm1;
	}
	
	
	

}
