package com.cg.bean;

public class Cab {
private String name;
private String mobile;
private String pickup,drop,cabtype;
private String otp;
private String price;
public Cab(String name, String mobile, String pickup, String drop, String cabtype, String otp,String price) {
	super();
	this.name = name;
	this.mobile = mobile;
	this.pickup = pickup;
	this.drop = drop;
	this.cabtype = cabtype;
	this.otp = otp;
	this.price=price;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
@Override
public String toString() {
	return "Cab [name=" + name + ", mobile=" + mobile + ", pickup=" + pickup + ", drop=" + drop + ", cabtype=" + cabtype
			+ ", otp=" + otp + ", price=" + price + "]";
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMobile() {
	return mobile;
}
public void setMobile(String mobile) {
	this.mobile = mobile;
}
public String getPickup() {
	return pickup;
}
public void setPickup(String pickup) {
	this.pickup = pickup;
}
public String getDrop() {
	return drop;
}
public void setDrop(String drop) {
	this.drop = drop;
}
public String getCabtype() {
	return cabtype;
}
public void setCabtype(String cabtype) {
	this.cabtype = cabtype;
}
public String getOtp() {
	return otp;
}
public void setOtp(String otp) {
	this.otp = otp;
}


}
