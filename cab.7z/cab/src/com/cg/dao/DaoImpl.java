package com.cg.dao;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.TreeMap;

import com.cg.bean.Cab;
import com.cg.util.CollectionUtil;

public class DaoImpl implements Idao{
CollectionUtil cu=new CollectionUtil();
	@Override
	public List<Cab> getCabDetails() {
		return cu.getCabDetails();
		
	}

	@Override
	public void cabBook(Cab cab) {
		cu.cabBook(cab);
		
	}

	@Override
	public List<Cab> sortedMap(Cab cab) {
		  
		return null;
		
	}

}
