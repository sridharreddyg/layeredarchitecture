package com.cg.dao;

import java.util.List;

import com.cg.bean.Cab;

public interface Idao {
public List<Cab> getCabDetails();
public void cabBook(Cab cab);
public List sortedMap(Cab cab);
}
