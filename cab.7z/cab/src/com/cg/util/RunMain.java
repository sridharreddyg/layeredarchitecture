package com.cg.util;

import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.SimpleTimeZone;

import com.cg.Exception.CabException;
import com.cg.bean.Cab;
import com.cg.service.ServiceImpl;

public class RunMain {
	public static void main(String[] args) {
		ServiceImpl si=new ServiceImpl();
		Scanner sc=null;
		String continueChoice ;
		System.out.println("welcome to GoRide");
		do {
		System.out.println("1.Book a Cab\n2:Get Booking Details\n3:exit");
		int choice;
		boolean choiceFlag = false;
		do {
			sc=new Scanner(System.in);
			System.out.println("enter your choice");
			try {
				
				 choice=sc.nextInt();
				choiceFlag = true;
				switch (choice) {
				case 1:
					sc.nextLine();
					String name;
					boolean nameFlag = false;
					do {
						sc = new Scanner(System.in);
						System.out.println("Enter name of the customer");
						name = sc.nextLine();
						try {
							si.validateName(name);
							nameFlag = true;
							break;
						} catch (CabException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!nameFlag);
					String pickup;
					boolean pickupFlag = false;
					do {
						sc = new Scanner(System.in);
						System.out.println("Enter pickup location");
						pickup = sc.nextLine();
						try {
							si.validatePickup(pickup);
							pickupFlag = true;
							break;

						} catch (CabException e) {
							pickupFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!pickupFlag);
					String mobile;
					boolean mobileFlag = false;
					do {
						sc = new Scanner(System.in);
						System.out.println("Enter phone number of the customer");
						mobile = sc.nextLine();
						try {
							si.validateMobile(mobile);
							mobileFlag = true;
							break;

						} catch (CabException e) {
							mobileFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!mobileFlag);
					String drop;
					boolean dropFlag=false;
					do {
						sc=new Scanner(System.in);
						System.out.println("enter the Drop location");
						drop=sc.nextLine();
						try {
							si.validateDrop(drop);
							dropFlag=true;
							break;	
						}catch(CabException e) {
							dropFlag=false;
							System.err.println(e.getMessage());		
						}	
					}while(!dropFlag);
					int price = 0;
					CollectionUtil cu=new CollectionUtil();
					System.out.println(cu.map);
					int cabtype;
					String s = null;
					boolean cabFlag = false;
					boolean selectFlag=false;
					do {
						sc = new Scanner(System.in);
						System.out.println("Enter Cab type");
						
						try {
							cabtype= sc.nextInt();
							selectFlag=true;
							switch (cabtype) {
							case 1:
								try {
									 s=si.validateCabType(String.valueOf(cabtype));
								System.out.println("selected cab is: "+s);
								cabFlag = true;
								int max=600;
								int min=300;
								int range=max-min+1;
								 price=(int)(Math.random()*range)+min;
								System.out.println("estimated price is: "+price);
								break;
								}
							 catch (CabException e) {
								cabFlag = false;
								System.err.println(e.getMessage());
							}	
							break;
						case 2:
							try {
								 s=si.validateCabType(String.valueOf(cabtype));
							System.out.println("selected cab is: "+s);
							cabFlag = true;
							int max=400;
							int min=100;
							int range=max-min+1;
							 price=(int)(Math.random()*range)+min;
							System.out.println("estimated price is: "+price);	
							break;
							}
						 catch (CabException e) {
							cabFlag = false;
							System.err.println(e.getMessage());
						}	
							break;
						case 3:
							try {
								 s=si.validateCabType(String.valueOf(cabtype));
							System.out.println("selected cab is: "+s);
							cabFlag = true;
							int max=10000;
							int min=500;
							int range=max-min+1;
							 price=(int)(Math.random()*range)+min;
							System.out.println("estimated price is: "+price);	
							break;
							}
						 catch (CabException e) {
							cabFlag = false;
							System.err.println(e.getMessage());
						}	
							break;
						case 4:
							try {
								 s=si.validateCabType(String.valueOf(cabtype));
							System.out.println("selected cab is: "+s);
							cabFlag = true;
							int max=700;
							int min=20;
							int range=max-min+1;
							 price=(int)(Math.random()*range)+min;
							System.out.println("estimated price is: "+price);	
						break;
							}
						 catch (CabException e) {
							cabFlag = false;
							System.err.println(e.getMessage());
						 }	
							break;
							}
							
							int otp;
							int min=100000;
							int max=999999;
							int range=max-min+1;
							otp=(int) (Math.random()*range)+min;
							System.out.println("your OTP is: " +otp);
							Cab c=new Cab(name, mobile, pickup, drop, s, String.valueOf(otp), String.valueOf(price));
							si.cabBook(c);
						}
						catch(InputMismatchException e)
						{
							selectFlag=false;
							System.err.println("Enter proper number");
						}
					}while(!selectFlag);
					break;
				
				case 2:
					System.out.println(si.getCabDetails());
					break;
				case 3:
					System.out.println("Thank You For Using GoRide");
					System.exit(0);
					break;

				default:
					System.out.println("enter only 1/2/3");
		
				}
			}catch(InputMismatchException e)
			{
				choiceFlag = false;
				System.err.println("enter only digits");	
			}
		}while(!choiceFlag);
		
		System.out.println("do u want to continue again(yes/no)");
		continueChoice = sc.next();
	
	}while(continueChoice.equalsIgnoreCase("yes"));
	}
}
	
		

	
		



