package com.cg.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.bean.Cab;

public class CollectionUtil {
public List<Cab> list=new ArrayList<Cab>();
public Map<Integer,String> map=new HashMap();
{
	map.put(1, "prime");
	map.put(2, "pool");
	map.put(3, "rentals");
	map.put(4, "auto");
}
public List<Cab> getCabDetails() {
	return list;
		
	}
public void cabBook(Cab cab) {
	list.add(cab);
	}
}
