package com.cg.MobilePurchase.Dao;

import java.rmi.server.UID;
import java.util.HashMap;
import java.util.Map;

import com.cg.MobilePurchase.Bean.Customer;
import com.cg.MobilePurchase.Bean.Mobile;
import com.cg.MobilePurchase.Exception.MobileException;
import com.cg.MobilePurchase.Util.Utility;

public class MobileDao implements IMobileDao {
	Map<Integer, Customer>hm2=new HashMap<Integer,Customer>();

	
	@Override
	public Mobile purchaseMobile(int mobilechoice) throws MobileException {
		
		
		Utility util=new Utility();
		
		return util.purchaseMobile(mobilechoice);
		
	}

	@Override
	public void storeIntoMap(Customer cust) throws MobileException {
		
		hm2.put(cust.getOrderID(), cust);
		
	}

	@Override
	public Customer GenBill(int genid) throws MobileException {
		
		return hm2.get(genid);
	}



}