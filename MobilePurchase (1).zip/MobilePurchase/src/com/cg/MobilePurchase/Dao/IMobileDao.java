package com.cg.MobilePurchase.Dao;

import com.cg.MobilePurchase.Bean.Customer;
import com.cg.MobilePurchase.Bean.Mobile;
import com.cg.MobilePurchase.Exception.MobileException;

public interface IMobileDao {

	Mobile purchaseMobile(int mobilechoice) throws MobileException;

	void storeIntoMap(Customer cust) throws MobileException;

	Customer GenBill(int genid) throws MobileException;





}