package com.cg.MobilePurchase.Util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.MobilePurchase.Bean.Customer;
import com.cg.MobilePurchase.Bean.Mobile;

public class Utility {
	
static Map<Integer, Mobile> hm1=new HashMap<Integer, Mobile>();
static {
	hm1.put(101, new Mobile(101,"Samsung",10000)); 
	hm1.put(202, new Mobile(202,"Gionee",20000)); 
	hm1.put(303, new Mobile(303,"MI",15000)); 
	hm1.put(404, new Mobile(404,"Zed",17000)); 
	hm1.put(102, new Mobile(505,"Vivo",14000)); 
	hm1.put(606, new Mobile(606,"Htc",9000)); 
	
}


public ArrayList<Mobile> displayMobiles() {



	
	ArrayList<Mobile> entryList = new ArrayList<Mobile>(hm1.values());

    Collections.sort(entryList,Mobile.StuNameComparator);
           
            
            
     



return  entryList;
		
	
}


/*public ArrayList<Entry<Integer, Mobile>> displayMobiles() {



	
	ArrayList<Entry<Integer, Mobile>> entryList = new ArrayList<Map.Entry<Integer, Mobile>>(hm1.entrySet());

    Collections.sort(
            entryList, new Comparator<Map.Entry<Integer, Mobile>>() {
      
        public int compare(Map.Entry<Integer, Mobile> integerMobileEntry,
                           Map.Entry<Integer, Mobile> integerMobileEntry2) {
            return integerMobileEntry.getValue().getMobileName()
                    .compareTo(integerMobileEntry2.getValue().getMobileName());
            
            
        }
    }
);


return  entryList;
		
	
}
*/

public Mobile purchaseMobile(int mobilechoice) {
	
	System.out.println("hello");
	return hm1.get(mobilechoice);
	
}





}